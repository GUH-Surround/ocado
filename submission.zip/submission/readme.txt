===========================================
To Run:
- install python2/3
- run "python ocado <filename.csv>"
- output in "spotify_exe_stopped_working.rule_10.csv"